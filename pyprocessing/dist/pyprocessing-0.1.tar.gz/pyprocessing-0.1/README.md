A simple preprocessing method. 
At the moment it offers PCP method and the IDF method as presented in the papers 
https://doi.org/10.1109/IJCNN.2019.8851888 & https://ieeexplore.ieee.org/document/8710472 respectively.